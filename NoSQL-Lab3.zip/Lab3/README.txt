!IMPORTANT!
Import Inquirer library in console propmt
$ pip install inquirer

Make sure that link to your DB is working and was same with actual link
Also check the names of collections.

After all, import JSONs to MongoDB via console propmt's mongoimport tool.